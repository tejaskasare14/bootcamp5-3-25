import React from 'react';
import ReactDOM from 'react-dom/client';
import Dashboard from './componenets/Dashboard';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css'
import '../node_modules/bootstrap/dist/js/bootstrap.min.js'
import {createBrowserRouter, RouterProvider} from 'react-router-dom'
import Contact from './componenets/Contact.js';
import Product from './componenets/Product.js';
import ErrorPage from './componenets/ErrorPage.js';
import ProductDetails from './componenets/ProductDetails.js';
import { ThemeProvider } from './context/ThemeContext.js';

const routes = createBrowserRouter([
  {
    path:'/',
    element:<Dashboard/>,
    errorElement:<ErrorPage/>,
    children:[
      {
        path:'/contact',
        element:<Contact/>
      },
      {
        path:'/product',
        element:<Product/>
      },
      {
        path:'/product/:id',
        element:<ProductDetails/>
      }
    ]
  }
])

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <ThemeProvider>
    <RouterProvider router={routes}>
      <Dashboard/>
    </RouterProvider>
  </ThemeProvider>
);
