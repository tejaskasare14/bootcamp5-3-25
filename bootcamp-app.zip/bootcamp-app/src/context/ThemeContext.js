
const { createContext, useState } = require("react");

export let ThemeContext=createContext()

export function ThemeProvider(props)
{

    let[theme,setTheme]=useState('light')
    let themeStyle ={}
    if(theme==='dark') 
        { themeStyle = {backgroundColor:'black',color:'white'}}
    else 
        {themeStyle = {backgroundColor:'white',color:'black'}}
    return(
        <ThemeContext.Provider value={{theme,setTheme,themeStyle}}>
            {props.children} {/* <Dashboard/> */}
        </ThemeContext.Provider>
    )
}
