import React from 'react'

export default function ErrorPage() {
  return (
    <div>
      This page is not available
    </div>
  )
}
