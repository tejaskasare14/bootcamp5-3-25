import React from 'react'

export default function SortProduct(props) {
  return (
    <div className='mb-3'>
        <div className="dropdown">
            <button className="btn btn-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                Sort Product
            </button>
            <ul className="dropdown-menu">
                <li> <button className='btn' onClick={()=>{props.onSortProductByPrice("asc")}}>Low to High</button> </li>  
                <li> <button className='btn' onClick={()=>{props.onSortProductByPrice("desc")}}>High to Low</button> </li>  
            </ul>
        </div>
    </div>
  )
}
