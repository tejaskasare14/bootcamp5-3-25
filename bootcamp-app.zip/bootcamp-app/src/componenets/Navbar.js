import React, { useContext } from 'react'
import {Link, NavLink} from 'react-router-dom'
import { ThemeContext } from '../context/ThemeContext';
export default function Navbar() {
  let {theme,setTheme}=useContext(ThemeContext)
  return (
    <div>
      <nav className="navbar navbar-expand-lg bg-body-tertiary" data-bs-theme="dark">
        <div className="container-fluid">
          <Link className="navbar-brand" to={'/'}>Navbar</Link>
          <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarSupportedContent">
            <ul className="navbar-nav me-auto mb-2 mb-lg-0">
              <li className="nav-item">
                <NavLink className="nav-link " aria-current="page" to={'/'}>Home</NavLink>
              </li>
              <li className="nav-item">
                <NavLink className="nav-link " aria-current="page" to={'/contact'}>Contact</NavLink>
              </li>
              <li className="nav-item">
                <Link className="nav-link " aria-current="page" to={'/product'}>Products</Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link " aria-current="page" to={'/'}>Cart</Link>
              </li>
            </ul>
          </div>
          {/* added new div below */}
          <div className='bg-warning p-2'>
            {
              theme==='dark'? 
              <img src='http://localhost:3000/light.png' style={{width:24+'px'}} onClick={()=>{setTheme('light')}}></img>:
              <img src='http://localhost:3000/dark.png' style={{width:24+'px'}} onClick={()=>{setTheme('dark')}}></img>
            }   
          </div>
        </div>
      </nav>
    </div>
  )
}
