import React, { useEffect, useState } from 'react'

export default function FilterProduct(props) {
    let [categories, setCategories]=useState(null)
    async function fetchAllCategories()
    {
        let response =await fetch("https://dummyjson.com/products/categories")
        let data= await response.json()
        setCategories(data)
    }
    useEffect(()=>{fetchAllCategories()},[])
return (
    <div className='mb-3'>
        <div className="dropdown">
            <button className="btn btn-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                Select Category
            </button>
            <ul className="dropdown-menu">
                <li> <button className='btn' onClick={()=>{props.onFilterProductByCategory("all")}}>All</button> </li>
                {
                   categories && categories.map(category => {
                    return (
                            <li> <button className='btn' onClick={()=>{props.onFilterProductByCategory(category.name)}}>{category.name}</button> </li>
                    )
                   }) 
                }
                
            </ul>
        </div>
    </div>
  )
}
