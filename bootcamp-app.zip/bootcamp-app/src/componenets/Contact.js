import React, { useContext } from 'react'
import { useForm } from 'react-hook-form'
import { ThemeContext } from '../context/ThemeContext';

export default function Contact() {
  //accessing context 
  let {themeStyle}=useContext(ThemeContext)

  let {register, handleSubmit, formState}=useForm()
  function collectFormData(formData)
  {
    console.log(formData); 
  }
  return (
    <div className='container d-flex justify-content-center mt-3 border border-3 p-5' style={themeStyle}>
      <form className='w-50' onSubmit={handleSubmit(collectFormData)}>
        <div className="mb-3">
          <label htmlFor="username" className="form-label">User Name:</label>
          <input type="text" className="form-control" id="username" 
          {...register('username',{required:true,minLength:4,maxLength:10})}/>
        </div>
        <p className='text-danger'>
          {formState.errors && formState.errors.username && formState.errors.username.type=='required' && 'UserName is required'}
          {formState.errors && formState.errors.username && formState.errors.username.type=='minLength' && 'min 4 characters required in username'}
          {formState.errors && formState.errors.username && formState.errors.username.type=='maxLength' && 'max 10 characters required in username'}
        </p>
        <div className="mb-3">
          <label htmlFor="userage" className="form-label">User Age:</label>
          <input type="number" className="form-control" id="userage" 
          {...register('userage',{required:true,min:18,max:80})}/>
        </div>
        <p className='text-danger'>
          {formState.errors && formState.errors.userage && formState.errors.userage.type=='required' && 'UserAge is required'}
          {formState.errors && formState.errors.userage && formState.errors.userage.type=='min' && 'min age 18 required'}
          {formState.errors && formState.errors.userage && formState.errors.userage.type=='max' && 'max age 80 required'}
        </p>
        <button type="submit" className="btn btn-primary">Submit</button>
      </form>
    </div>
  )
}
