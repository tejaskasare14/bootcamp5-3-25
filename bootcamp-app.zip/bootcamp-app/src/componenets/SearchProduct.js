import React from 'react'
import { useForm } from 'react-hook-form';

export default function SearchProduct(props) {
    let {register, handleSubmit, formState}=useForm()
      function collectFormData(formData)
      {
        console.log(formData); 
        props.onSearchProductByName(formData.productName)
      }
  return (
    <div >
      <form className='d-flex' onSubmit={handleSubmit(collectFormData)}>
        <div className='me-3'>
          <input type="text" className="form-control" id="productName" 
          {...register('productName',{required:true,minLength:4,maxLength:10})}/>
          <span className='text-danger'>
          {formState.errors && formState.errors.productName && formState.errors.productName.type=='required' && 'productName is required'}
          {formState.errors && formState.errors.productName && formState.errors.productName.type=='minLength' && 'min 4 characters required in productName'}
          {formState.errors && formState.errors.productName && formState.errors.productName.type=='maxLength' && 'max 10 characters required in productName'}
        </span>
        </div>
        
        <button type="submit" className="btn btn-primary">Search</button>
      </form>
    </div>
  )
}
