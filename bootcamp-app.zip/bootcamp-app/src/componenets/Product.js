import React, { use, useContext, useEffect, useState } from 'react'
import { Link } from 'react-router-dom';
import FilterProduct from './FilterProduct';
import SortProduct from './SortProduct';
import SearchProduct from './SearchProduct';
import { ThemeContext } from '../context/ThemeContext';
// const products = [{name:'mobile',price:200},{name:'laptop',price:600}]
export default function Product() {
  //let products = [{name:'mobile',price:200},{name:'laptop',price:600}]
  //let[variableToStoreDefaultvalue, functionToUpdateVariable]=useState(default state/value)
  let[products, setProducts ]=useState(null)
  let[filteredProducts,setFilteredProducts] = useState(null)
  //let [counter, setCounter]=useState(0)

   //accessing context - context code start
   let {themeStyle}=useContext(ThemeContext)

  async function fetchProucts()
  {
    let response=await fetch("https://dummyjson.com/products",{method:'GET'})
    let data=await response.json()
    console.log(data);
    console.log(data.products);
    //products = data.products
    setProducts(data.products)
    setFilteredProducts(data.products) //here filteredProducts have all products
  }
  //fetchProucts()
  // useEffect(()=>{
  //   fetchProucts()
  // },[counter])
  useEffect(()=>{
    fetchProucts()
  },[])

  // async function filterProductByCategory(url)
  // {
  //   let response=await fetch(url,{method:'GET'})
  //   let data=await response.json()
  //   console.log(data);
  //   console.log(data.products);
  //   setProducts(data.products)
  // }
  function filterProductByCategory(categoryName)
  {
    
      let filtredProductsBasedOnCategory=products.filter(product => 
        {
          return product.category.toLowerCase().includes(categoryName.toLowerCase())
        })
        
      setFilteredProducts(filtredProductsBasedOnCategory)
      
  }
  // async function sortProductByPrice(url)
  // {
  //   let response=await fetch(url,{method:'GET'})
  //   let data=await response.json()
  //   console.log(data);
  //   console.log(data.products);
  //   //products = data.products
  //   setProducts(data.products)
  // }
  function sortProductByPrice(sortingType)
  {
    let data = [...filteredProducts];
    if(sortingType==='asc')
    {
        data.sort((obj1, obj2)=> obj1.price-obj2.price)
    }
    else
    {
      data.sort((obj1, obj2)=> obj2.price-obj1.price)
    }
    
    setFilteredProducts(data)
  }

  function searchProductByName(productName)
  {
    
    let data = [...filteredProducts];
    let newdata = data.filter(product => {return product.title.toLowerCase().includes(productName.toLowerCase())})
    setFilteredProducts(newdata)
  }
  return (  
    <div className='container mt-3 p-3' style={themeStyle}>
      <div className='d-flex justify-content-between'>
      <FilterProduct onFilterProductByCategory={filterProductByCategory}/>
      <SortProduct onSortProductByPrice={sortProductByPrice}/>
      <SearchProduct onSearchProductByName={searchProductByName}/>
      </div>
      {/* <p>{counter}</p>
      <button onClick={()=>{setCounter(counter+1)}}>change counter</button> */}
      <div className='row'>
        {
          // products && products.map(product => {
            
            filteredProducts && filteredProducts.map(product => {
            return (
              <div className='col-3 mb-3' key={product.id}>
                  <div className="card" style={{width:18+"rem"}}>
                      <img src={product.thumbnail} className="card-img-top" alt="..."/>
                      <div className="card-body">
                        <h5 className="card-title">{product.title.slice(0,15)}</h5>
                        <p className="card-text">{product.description.slice(0,95)}...</p>
                        <p className="card-text bg-warning">{product.category}</p>
                        {/* <p><del>&#8377;{product.price}</del>  &#8377;{product.discountPercentage}</p> */}
                        <p>{product.price}</p>
                        <Link to={`/product/${product.id}`} className="btn btn-primary">View More</Link>
                      </div>
                    </div>
                </div>
            )
          })
        }   
      </div>
    </div>
  )

}
