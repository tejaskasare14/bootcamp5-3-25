import React, { useEffect, useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'

export default function ProductDetails() {
  let urlParams=useParams()
  let navigate=useNavigate()
  console.log(urlParams);
  console.log(urlParams.id);
  let id = urlParams.id
  let[product, setProduct]=useState(null)
  async function fetchProuctById()
  {
    let response=await fetch(`https://dummyjson.com/products/${id}`,{method:'GET'})
    let data=await response.json()
    console.log(data);
    setProduct(data)
  }
  useEffect(()=>{fetchProuctById()},[])
  return (
    product &&
   <div className='container mt-3'>
        <div className='row'>
            <div className='col-3 mb-3' key={product.id}>
                  <div className="card" style={{width:18+"rem"}}>
                      <img src={product.thumbnail} className="card-img-top" alt="..."/>
                      <div className="card-body">
                        <h5 className="card-title">{product.title.slice(0,15)}</h5>
                        <p className="card-text">{product.description.slice(0,95)}...</p>
                        <p><del>&#8377;{product.price}</del>  &#8377;{product.discountPercentage}</p> 
                        <button className='btn btn-dark text-light' onClick={()=>{navigate('/product')}}>Back</button>                     
                      </div>
                  </div>
              </div>   
        </div>
    </div>
  )
}
