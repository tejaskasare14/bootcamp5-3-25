//named function
function add(n1,n2)
{
    let result = n1+n2;
    console.log(result);
}

add(10,5)

//anonymous function
let sub=function (n1,n2)
{
    let result = n1-n2;
    console.log(result);
}

sub(10,5)

//arrow function
let div= (n1,n2) =>
{
    let result = n1/n2;
    console.log(result);
}

div(10,5)
//one time use - call back function
